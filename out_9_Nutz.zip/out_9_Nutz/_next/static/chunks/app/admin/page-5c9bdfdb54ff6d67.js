(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[3],{5531:function(e,t,r){"use strict";r.d(t,{Z:function(){return l}});var a=r(2265);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),n=(...e)=>e.filter((e,t,r)=>!!e&&r.indexOf(e)===t).join(" ");/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var o={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,a.forwardRef)(({color:e="currentColor",size:t=24,strokeWidth:r=2,absoluteStrokeWidth:s,className:i="",children:l,iconNode:c,...d},u)=>(0,a.createElement)("svg",{ref:u,...o,width:t,height:t,stroke:e,strokeWidth:s?24*Number(r)/Number(t):r,className:n("lucide",i),...d},[...c.map(([e,t])=>(0,a.createElement)(e,t)),...Array.isArray(l)?l:[l]])),l=(e,t)=>{let r=(0,a.forwardRef)(({className:r,...o},l)=>(0,a.createElement)(i,{ref:l,iconNode:t,className:n(`lucide-${s(e)}`,r),...o}));return r.displayName=`${e}`,r}},8291:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});var a=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a.Z)("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]])},7216:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});var a=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a.Z)("EyeOff",[["path",{d:"M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",key:"ct8e1f"}],["path",{d:"M14.084 14.158a3 3 0 0 1-4.242-4.242",key:"151rxh"}],["path",{d:"M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",key:"13bj9a"}],["path",{d:"m2 2 20 20",key:"1ooewy"}]])},9670:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});var a=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a.Z)("Eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]])},5589:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});var a=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a.Z)("Lock",[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]])},1295:function(e,t,r){"use strict";r.d(t,{Z:function(){return s}});var a=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let s=(0,a.Z)("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]])},3007:function(e,t,r){Promise.resolve().then(r.bind(r,5363))},5363:function(e,t,r){"use strict";r.r(t),r.d(t,{default:function(){return f}});var a=r(7437),s=r(2265),n=r(4033),o=r(2502),i=r(1295),l=r(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let c=(0,l.Z)("Loader",[["path",{d:"M12 2v4",key:"3427ic"}],["path",{d:"m16.2 7.8 2.9-2.9",key:"r700ao"}],["path",{d:"M18 12h4",key:"wj9ykh"}],["path",{d:"m16.2 16.2 2.9 2.9",key:"1bxg5t"}],["path",{d:"M12 18v4",key:"jadmvz"}],["path",{d:"m4.9 19.1 2.9-2.9",key:"bwix9q"}],["path",{d:"M2 12h4",key:"j09sii"}],["path",{d:"m4.9 4.9 2.9 2.9",key:"giyufr"}]]);var d=r(8291),u=r(5589),m=r(7216),p=r(9670);function f(){let[e,t]=(0,s.useState)(""),[r,l]=(0,s.useState)(""),[f,h]=(0,s.useState)(!1),[g,y]=(0,s.useState)(!1),[b,x]=(0,s.useState)(""),[v,w]=(0,s.useState)(!1),[j,k]=(0,s.useState)(""),[N,E]=(0,s.useState)(""),{login:S,resetPassword:C,user:A,isLoading:P}=(0,o.useAuth)(),I=(0,n.useRouter)();(0,s.useEffect)(()=>{!P&&A&&"admin"===A.role&&I.push("/admin/dashboard")},[A,P,I]);let L=async t=>{t.preventDefault(),y(!0),x("");try{let t=await S(e.trim(),r);t?setTimeout(()=>{let e=localStorage.getItem("user"),t=e?JSON.parse(e):null;t&&"admin"===t.role?I.push("/admin/dashboard"):x("Not an admin user.")},50):x("Invalid admin credentials")}catch(e){x("Login failed. Please try again.")}finally{y(!1)}},_=async e=>{e.preventDefault(),y(!0),E("");try{let e=await C(j);e?(E("Password reset request handled (dev-mode)."),setTimeout(()=>{w(!1),E("")},2e3)):E("Failed to reset password.")}catch(e){E("Failed to send reset email. Please try again.")}finally{y(!1)}};return v?(0,a.jsx)("div",{className:"min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4",children:(0,a.jsxs)("div",{className:"bg-white rounded-2xl shadow-xl w-full max-w-md p-8",children:[(0,a.jsxs)("div",{className:"text-center mb-8",children:[(0,a.jsx)("div",{className:"w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4",children:(0,a.jsx)("span",{className:"text-white font-bold text-2xl",children:"JB"})}),(0,a.jsx)("h1",{className:"text-2xl font-bold text-gray-900 mb-2",children:"Reset Password"}),(0,a.jsx)("p",{className:"text-gray-600",children:"Enter your email to receive reset instructions"})]}),(0,a.jsxs)("form",{onSubmit:_,className:"space-y-6",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{htmlFor:"resetEmail",className:"block text-sm font-medium text-gray-700 mb-2",children:"Email Address"}),(0,a.jsxs)("div",{className:"relative",children:[(0,a.jsx)(i.Z,{className:"absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400"}),(0,a.jsx)("input",{id:"resetEmail",type:"email",required:!0,value:j,onChange:e=>k(e.target.value),className:"w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent",placeholder:"admin@jbasket.com"})]})]}),N&&(0,a.jsx)("div",{className:"p-3 rounded-lg text-sm ".concat(N.includes("success")?"bg-green-100 text-green-700":"bg-red-100 text-red-700"),children:N}),(0,a.jsxs)("div",{className:"space-y-4",children:[(0,a.jsx)("button",{type:"submit",disabled:g,className:"w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-300 text-white py-3 px-4 rounded-lg font-medium transition-colors flex items-center justify-center",children:g?(0,a.jsx)(c,{className:"h-5 w-5 animate-spin"}):(0,a.jsxs)(a.Fragment,{children:["Send Reset Email ",(0,a.jsx)(d.Z,{className:"ml-2 h-5 w-5"})]})}),(0,a.jsx)("button",{type:"button",onClick:()=>w(!1),className:"w-full text-green-600 hover:text-green-700 py-3 font-medium transition-colors",children:"Back to Login"})]})]})]})}):(0,a.jsx)("div",{className:"min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items_center justify-center p-4",children:(0,a.jsxs)("div",{className:"bg-white rounded-2xl shadow-xl w-full max-w-md p-8",children:[(0,a.jsxs)("div",{className:"text-center mb-8",children:[(0,a.jsx)("div",{className:"w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4",children:(0,a.jsx)("span",{className:"text-white font-bold text-2xl",children:"JB"})}),(0,a.jsx)("h1",{className:"text-2xl font-bold text-gray-900 mb-2",children:"Admin Login"}),(0,a.jsx)("p",{className:"text-gray-600",children:"Access your JBasket admin dashboard"})]}),(0,a.jsxs)("form",{onSubmit:L,className:"space-y-6",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{htmlFor:"email",className:"block text-sm font-medium text-gray-700 mb-2",children:"Email Address"}),(0,a.jsxs)("div",{className:"relative",children:[(0,a.jsx)(i.Z,{className:"absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400"}),(0,a.jsx)("input",{id:"email",type:"email",required:!0,value:e,onChange:e=>t(e.target.value),className:"w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus_border-transparent",placeholder:"admin@jbasket.com"})]})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{htmlFor:"password",className:"block text-sm font-medium text-gray-700 mb-2",children:"Password"}),(0,a.jsxs)("div",{className:"relative",children:[(0,a.jsx)(u.Z,{className:"absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400"}),(0,a.jsx)("input",{id:"password",type:f?"text":"password",required:!0,value:r,onChange:e=>l(e.target.value),className:"w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent",placeholder:"Enter your password"}),(0,a.jsx)("button",{type:"button",onClick:()=>h(!f),className:"absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600",children:f?(0,a.jsx)(m.Z,{className:"h-5 w-5"}):(0,a.jsx)(p.Z,{className:"h-5 w-5"})})]})]}),b&&(0,a.jsx)("div",{className:"bg-red-100 text-red-700 p-3 rounded-lg text-sm",children:b}),(0,a.jsxs)("div",{className:"space-y-4",children:[(0,a.jsx)("button",{type:"submit",disabled:g,className:"w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-300 text-white py-3 px-4 rounded-lg font-medium transition-colors flex items-center justify-center",children:g?(0,a.jsx)(c,{className:"h-5 w-5 animate-spin"}):(0,a.jsxs)(a.Fragment,{children:["Login ",(0,a.jsx)(d.Z,{className:"ml-2 h-5 w-5"})]})}),(0,a.jsx)("button",{type:"button",onClick:()=>w(!0),className:"w-full text-green-600 hover:text-green-700 py-2 font-medium transition-colors",children:"Forgot Password?"})]})]}),(0,a.jsxs)("div",{className:"mt-8 p-4 bg-blue-50 rounded-lg",children:[(0,a.jsx)("h3",{className:"font-semibold text-blue-900 mb-2",children:"Demo Credentials"}),(0,a.jsxs)("p",{className:"text-sm text-blue-700",children:[(0,a.jsx)("strong",{children:"Email:"})," admin@jbasket.com",(0,a.jsx)("br",{}),(0,a.jsx)("strong",{children:"Password:"})," admin123"]})]})]})})}},2502:function(e,t,r){"use strict";r.r(t),r.d(t,{AuthProvider:function(){return h},useAuth:function(){return p}});var a=r(7437),s=r(2265),n=r(5925),o=r(8207),i=r(4033),l=r(4829),c=r(2601);let d=(c.env.NEXT_PUBLIC_API_BASE_URL||c.env.PROD_API_URL||"https://9nutsapi.nearbydoctors.in/public/api/").replace(/\/+$/,""),u=l.Z.create({baseURL:d,headers:{"Content-Type":"application/json"}});u.interceptors.request.use(e=>{{let t=window.localStorage.getItem("token");t&&(e.headers.Authorization="Bearer ".concat(t))}return e},e=>Promise.reject(e)),u.interceptors.response.use(e=>e,e=>Promise.reject(e));let m=(0,s.createContext)(void 0),p=()=>{let e=(0,s.useContext)(m);if(void 0===e)throw Error("useAuth must be used within an AuthProvider");return e},f=o.I,h=e=>{let{children:t}=e,[r,o]=(0,s.useState)(null),[l,c]=(0,s.useState)(!0),[d,u]=(0,s.useState)(null),p=(0,i.useRouter)();function h(e,t){e?localStorage.setItem("token",e):localStorage.removeItem("token"),t?localStorage.setItem("user",JSON.stringify(t)):localStorage.removeItem("user"),u(e),o(t)}(0,s.useEffect)(()=>{(async()=>{try{let e=localStorage.getItem("token");if(e){let t=localStorage.getItem("user");t&&o(JSON.parse(t)),u(e)}}catch(e){}finally{c(!1)}})()},[]);let g=async(e,t)=>{c(!0);try{let r=await fetch("".concat(f,"/user-login"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:e,password:t})}),a=await r.json();if(!r.ok||!a)return n.default.error(String((null==a?void 0:a.message)||"Login failed")),!1;let s=(null==a?void 0:a.token)||(null==a?void 0:a.access)||(null==a?void 0:a.access_token)||null,o=(null==a?void 0:a.user)||(null==a?void 0:a.data)||{id:a.id||"1",email:e,name:a.name||"User",role:"user"};if(!s)return!1;return h(s,o),n.default.success("Logged in successfully"),!0}catch(e){return n.default.error("Login error"),!1}finally{c(!1)}},y=async(e,t,r,a)=>{c(!0);try{let s=await fetch("".concat(f,"/register"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:e,email:t,password:r,...a?{contact:a}:{}})}),o=await s.json();if(!s.ok||void 0!==o.status&&!o.status)return n.default.error(String((null==o?void 0:o.message)||"Signup failed")),!1;let i=await g(t,r);return i&&n.default.success("Account created & logged in"),i}catch(e){return n.default.error("Signup error"),!1}finally{c(!1)}},b=async e=>{try{return await new Promise(e=>setTimeout(e,800)),!0}catch(e){return!1}},x=async()=>{if(d)try{let e=await fetch("".concat(f,"/api/user-profile"),{headers:{Authorization:"Bearer ".concat(d)}}),t=await e.json(),r={id:String(t.id),email:t.email,name:t.name,role:String(t.role||"user").toLowerCase()};o(r)}catch(e){}};return(0,a.jsx)(m.Provider,{value:{user:r,isLoading:l,login:g,logout:()=>{h(null,null),n.default.success("Logged out"),p.push("/")},signup:y,resetPassword:b,token:d,refreshMe:x},children:t})}},8207:function(e,t,r){"use strict";r.d(t,{DI:function(){return d},I:function(){return i},Sg:function(){return n},_g:function(){return l},bA:function(){return u},kE:function(){return o},nm:function(){return m}});var a=r(4829),s=r(2601);let n=(s.env.NEXT_PUBLIC_API_BASE||"https://ecom.nearbydoctors.in").replace(/\/+$/,""),o=(s.env.NEXT_PUBLIC_API_BASE_URL||"https://api.9nutz.com/api").replace(/\/+$/,""),i="https://9nutsapi.nearbydoctors.in/public/api".replace(/\/+$/,""),l="https://checkout.razorpay.com/v1/checkout.js";async function c(e){var t;let r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},a=function(e){if(!e)return n;if(/^https?:\/\//i.test(e))return e;let t=String(e).replace(/^\/+/,"");return"".concat(n,"/").concat(t)}(e),s={method:r.method||"GET",headers:{...r.headers||{}},credentials:null!==(t=r.credentials)&&void 0!==t?t:"same-origin"};void 0!==r.body&&(s.headers={...s.headers||{},"Content-Type":"application/json"},s.body=JSON.stringify(r.body)),r.token&&(s.headers={...s.headers||{},Authorization:"Bearer ".concat(r.token)});let o=await fetch(a,s),i=await o.text(),l=null;try{l=i?JSON.parse(i):null}catch(e){l=i}if(!o.ok){let e=(null==l?void 0:l.message)||l||o.statusText,t=Error(String(e));throw t.status=o.status,t.body=l,t}return l}let d=(e,t)=>c("/api/admin/categories",{method:"POST",body:e,token:t}),u=(e,t,r)=>c("/api/admin/categories/".concat(e),{method:"PUT",body:t,token:r}),m=(e,t)=>c("/api/admin/categories/".concat(e),{method:"DELETE",token:t}),p=a.Z.create({baseURL:o,headers:{"Content-Type":"application/json"}});p.interceptors.request.use(e=>{{let t=window.localStorage.getItem("token");t&&(e.headers.Authorization="Bearer ".concat(t))}return e},e=>Promise.reject(e)),p.interceptors.response.use(e=>e,e=>Promise.reject(e)),t.ZP=p},4033:function(e,t,r){e.exports=r(290)},5925:function(e,t,r){"use strict";let a,s;r.r(t),r.d(t,{CheckmarkIcon:function(){return q},ErrorIcon:function(){return U},LoaderIcon:function(){return J},ToastBar:function(){return et},ToastIcon:function(){return W},Toaster:function(){return en},default:function(){return eo},resolveValue:function(){return N},toast:function(){return M},useToaster:function(){return F},useToasterStore:function(){return z}});var n,o=r(2265);let i={data:""},l=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||i},c=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,d=/\/\*[^]*?\*\/|  +/g,u=/\n+/g,m=(e,t)=>{let r="",a="",s="";for(let n in e){let o=e[n];"@"==n[0]?"i"==n[1]?r=n+" "+o+";":a+="f"==n[1]?m(o,n):n+"{"+m(o,"k"==n[1]?"":t)+"}":"object"==typeof o?a+=m(o,t?t.replace(/([^,])+/g,e=>n.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):n):null!=o&&(n=/^--/.test(n)?n:n.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=m.p?m.p(n,o):n+":"+o+";")}return r+(t&&s?t+"{"+s+"}":s)+a},p={},f=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+f(e[r]);return t}return e},h=(e,t,r,a,s)=>{var n;let o=f(e),i=p[o]||(p[o]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(o));if(!p[i]){let t=o!==e?e:(e=>{let t,r,a=[{}];for(;t=c.exec(e.replace(d,""));)t[4]?a.shift():t[3]?(r=t[3].replace(u," ").trim(),a.unshift(a[0][r]=a[0][r]||{})):a[0][t[1]]=t[2].replace(u," ").trim();return a[0]})(e);p[i]=m(s?{["@keyframes "+i]:t}:t,r?"":"."+i)}let l=r&&p.g?p.g:null;return r&&(p.g=p[i]),n=p[i],l?t.data=t.data.replace(l,n):-1===t.data.indexOf(n)&&(t.data=a?n+t.data:t.data+n),i},g=(e,t,r)=>e.reduce((e,a,s)=>{let n=t[s];if(n&&n.call){let e=n(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;n=t?"."+t:e&&"object"==typeof e?e.props?"":m(e,""):!1===e?"":e}return e+a+(null==n?"":n)},"");function y(e){let t=this||{},r=e.call?e(t.p):e;return h(r.unshift?r.raw?g(r,[].slice.call(arguments,1),t.p):r.reduce((e,r)=>Object.assign(e,r&&r.call?r(t.p):r),{}):r,l(t.target),t.g,t.o,t.k)}y.bind({g:1});let b,x,v,w=y.bind({k:1});function j(e,t){let r=this||{};return function(){let a=arguments;function s(n,o){let i=Object.assign({},n),l=i.className||s.className;r.p=Object.assign({theme:x&&x()},i),r.o=/ *go\d+/.test(l),i.className=y.apply(r,a)+(l?" "+l:""),t&&(i.ref=o);let c=e;return e[0]&&(c=i.as||e,delete i.as),v&&c[0]&&v(i),b(c,i)}return t?t(s):s}}var k=e=>"function"==typeof e,N=(e,t)=>k(e)?e(t):e,E=(a=0,()=>(++a).toString()),S=()=>{if(void 0===s&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");s=!e||e.matches}return s},C="default",A=(e,t)=>{let{toastLimit:r}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,r)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return A(e,{type:e.toasts.find(e=>e.id===a.id)?1:0,toast:a});case 3:let{toastId:s}=t;return{...e,toasts:e.toasts.map(e=>e.id===s||void 0===s?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let n=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+n}))}}},P=[],I={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},L={},_=(e,t=C)=>{L[t]=A(L[t]||I,e),P.forEach(([e,r])=>{e===t&&r(L[t])})},O=e=>Object.keys(L).forEach(t=>_(e,t)),T=e=>Object.keys(L).find(t=>L[t].toasts.some(t=>t.id===e)),$=(e=C)=>t=>{_(t,e)},Z={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},z=(e={},t=C)=>{let[r,a]=(0,o.useState)(L[t]||I),s=(0,o.useRef)(L[t]);(0,o.useEffect)(()=>(s.current!==L[t]&&a(L[t]),P.push([t,a]),()=>{let e=P.findIndex(([e])=>e===t);e>-1&&P.splice(e,1)}),[t]);let n=r.toasts.map(t=>{var r,a,s;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(a=e[t.type])?void 0:a.duration)||(null==e?void 0:e.duration)||Z[t.type],style:{...e.style,...null==(s=e[t.type])?void 0:s.style,...t.style}}});return{...r,toasts:n}},D=(e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||E()}),B=e=>(t,r)=>{let a=D(t,e,r);return $(a.toasterId||T(a.id))({type:2,toast:a}),a.id},M=(e,t)=>B("blank")(e,t);M.error=B("error"),M.success=B("success"),M.loading=B("loading"),M.custom=B("custom"),M.dismiss=(e,t)=>{let r={type:3,toastId:e};t?$(t)(r):O(r)},M.dismissAll=e=>M.dismiss(void 0,e),M.remove=(e,t)=>{let r={type:4,toastId:e};t?$(t)(r):O(r)},M.removeAll=e=>M.remove(void 0,e),M.promise=(e,t,r)=>{let a=M.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let s=t.success?N(t.success,e):void 0;return s?M.success(s,{id:a,...r,...null==r?void 0:r.success}):M.dismiss(a),e}).catch(e=>{let s=t.error?N(t.error,e):void 0;s?M.error(s,{id:a,...r,...null==r?void 0:r.error}):M.dismiss(a)}),e};var R=1e3,F=(e,t="default")=>{let{toasts:r,pausedAt:a}=z(e,t),s=(0,o.useRef)(new Map).current,n=(0,o.useCallback)((e,t=R)=>{if(s.has(e))return;let r=setTimeout(()=>{s.delete(e),i({type:4,toastId:e})},t);s.set(e,r)},[]);(0,o.useEffect)(()=>{if(a)return;let e=Date.now(),s=r.map(r=>{if(r.duration===1/0)return;let a=(r.duration||0)+r.pauseDuration-(e-r.createdAt);if(a<0){r.visible&&M.dismiss(r.id);return}return setTimeout(()=>M.dismiss(r.id,t),a)});return()=>{s.forEach(e=>e&&clearTimeout(e))}},[r,a,t]);let i=(0,o.useCallback)($(t),[t]),l=(0,o.useCallback)(()=>{i({type:5,time:Date.now()})},[i]),c=(0,o.useCallback)((e,t)=>{i({type:1,toast:{id:e,height:t}})},[i]),d=(0,o.useCallback)(()=>{a&&i({type:6,time:Date.now()})},[a,i]),u=(0,o.useCallback)((e,t)=>{let{reverseOrder:a=!1,gutter:s=8,defaultPosition:n}=t||{},o=r.filter(t=>(t.position||n)===(e.position||n)&&t.height),i=o.findIndex(t=>t.id===e.id),l=o.filter((e,t)=>t<i&&e.visible).length;return o.filter(e=>e.visible).slice(...a?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+s,0)},[r]);return(0,o.useEffect)(()=>{r.forEach(e=>{if(e.dismissed)n(e.id,e.removeDelay);else{let t=s.get(e.id);t&&(clearTimeout(t),s.delete(e.id))}})},[r,n]),{toasts:r,handlers:{updateHeight:c,startPause:l,endPause:d,calculateOffset:u}}},U=j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${w`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${w`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${w`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,J=j("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${w`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`} 1s linear infinite;
`,q=j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${w`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${w`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,H=j("div")`
  position: absolute;
`,X=j("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,V=j("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${w`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,W=({toast:e})=>{let{icon:t,type:r,iconTheme:a}=e;return void 0!==t?"string"==typeof t?o.createElement(V,null,t):t:"blank"===r?null:o.createElement(X,null,o.createElement(J,{...a}),"loading"!==r&&o.createElement(H,null,"error"===r?o.createElement(U,{...a}):o.createElement(q,{...a})))},G=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,Y=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,K=j("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Q=j("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,ee=(e,t)=>{let r=e.includes("top")?1:-1,[a,s]=S()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[G(r),Y(r)];return{animation:t?`${w(a)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${w(s)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},et=o.memo(({toast:e,position:t,style:r,children:a})=>{let s=e.height?ee(e.position||t||"top-center",e.visible):{opacity:0},n=o.createElement(W,{toast:e}),i=o.createElement(Q,{...e.ariaProps},N(e.message,e));return o.createElement(K,{className:e.className,style:{...s,...r,...e.style}},"function"==typeof a?a({icon:n,message:i}):o.createElement(o.Fragment,null,n,i))});n=o.createElement,m.p=void 0,b=n,x=void 0,v=void 0;var er=({id:e,className:t,style:r,onHeightUpdate:a,children:s})=>{let n=o.useCallback(t=>{if(t){let r=()=>{a(e,t.getBoundingClientRect().height)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,a]);return o.createElement("div",{ref:n,className:t,style:r},s)},ea=(e,t)=>{let r=e.includes("top"),a=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:S()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(r?1:-1)}px)`,...r?{top:0}:{bottom:0},...a}},es=y`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,en=({reverseOrder:e,position:t="top-center",toastOptions:r,gutter:a,children:s,toasterId:n,containerStyle:i,containerClassName:l})=>{let{toasts:c,handlers:d}=F(r,n);return o.createElement("div",{"data-rht-toaster":n||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...i},className:l,onMouseEnter:d.startPause,onMouseLeave:d.endPause},c.map(r=>{let n=r.position||t,i=ea(n,d.calculateOffset(r,{reverseOrder:e,gutter:a,defaultPosition:t}));return o.createElement(er,{id:r.id,key:r.id,onHeightUpdate:d.updateHeight,className:r.visible?es:"",style:i},"custom"===r.type?N(r.message,r):s?s(r):o.createElement(et,{toast:r,position:n}))}))},eo=M}},function(e){e.O(0,[4737,2971,7864,1744],function(){return e(e.s=3007)}),_N_E=e.O()}]);