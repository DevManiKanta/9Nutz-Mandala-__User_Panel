(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[7301],{5117:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});var r=s(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r.Z)("ArrowUp",[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]])},3021:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});var r=s(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r.Z)("Bell",[["path",{d:"M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9",key:"1qo2s2"}],["path",{d:"M10.3 21a1.94 1.94 0 0 0 3.4 0",key:"qgo35s"}]])},1798:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});var r=s(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r.Z)("Facebook",[["path",{d:"M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z",key:"1jg4f8"}]])},7810:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});var r=s(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r.Z)("Heart",[["path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}]])},6539:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});var r=s(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r.Z)("Instagram",[["rect",{width:"20",height:"20",x:"2",y:"2",rx:"5",ry:"5",key:"2e1cvw"}],["path",{d:"M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z",key:"9exkf1"}],["line",{x1:"17.5",x2:"17.51",y1:"6.5",y2:"6.5",key:"r4j83e"}]])},7461:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});var r=s(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r.Z)("Linkedin",[["path",{d:"M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z",key:"c2jq9f"}],["rect",{width:"4",height:"12",x:"2",y:"9",key:"mk3on5"}],["circle",{cx:"4",cy:"4",r:"2",key:"bt5ra8"}]])},9142:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});var r=s(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r.Z)("PhoneCall",[["path",{d:"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z",key:"foiqr5"}],["path",{d:"M14.05 2a9 9 0 0 1 8 7.94",key:"vmijpz"}],["path",{d:"M14.05 6A5 5 0 0 1 18 10",key:"13nbpp"}]])},3505:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});var r=s(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r.Z)("ShoppingCart",[["circle",{cx:"8",cy:"21",r:"1",key:"jimo8o"}],["circle",{cx:"19",cy:"21",r:"1",key:"13723u"}],["path",{d:"M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12",key:"9zh506"}]])},7972:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});var r=s(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r.Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},9199:function(e,t,s){"use strict";s.d(t,{Z:function(){return a}});var r=s(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let a=(0,r.Z)("Youtube",[["path",{d:"M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17",key:"1q2vi4"}],["path",{d:"m10 15 5-3-5-3z",key:"1jp15x"}]])},8645:function(e,t,s){Promise.resolve().then(s.bind(s,8344))},8344:function(e,t,s){"use strict";s.r(t),s.d(t,{default:function(){return n}});var r=s(7437);s(2265);var a=s(1396),i=s.n(a);function n(){return(0,r.jsx)("div",{className:"min-h-screen bg-gray-50",children:(0,r.jsx)("main",{className:"pb-12",children:(0,r.jsxs)("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:[(0,r.jsx)("section",{className:"bg-white rounded-2xl shadow-sm border overflow-hidden mb-8",children:(0,r.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6 items-center",children:[(0,r.jsxs)("div",{className:"p-8 sm:p-12",children:[(0,r.jsx)("h1",{className:"text-3xl sm:text-4xl font-extrabold text-emerald-800 mb-4",children:"9NUTZ MILLETS"}),(0,r.jsxs)("p",{className:"text-gray-700 mb-4",children:["In 2020, during the global pandemic, we saw people forced into unhealthy choices because healthier options weren't available or convenient. That sparked a question: ",(0,r.jsx)("em",{children:"why can't traditional, healthier snacks be as accessible as fast food?"})," That's how our entrepreneurial journey began — and 9NUTZ MILLETS was born."]}),(0,r.jsxs)("p",{className:"text-gray-700 mb-4",children:["Our mission is to revolutionize snacking habits across India by offering nutritious alternatives that empower families to make healthier choices. We aim to ",(0,r.jsx)("strong",{children:"un-junk the snacks"}),", enrich lives with millets, and promote well-being through mindful eating."]}),(0,r.jsxs)("p",{className:"text-gray-700 mb-4",children:["I started this journey in 2020 under the name ",(0,r.jsx)("strong",{children:"9NUTZ MILLETS Pvt. Ltd."})," — committed to providing value-added foods made with millets that avoid sugar, refined flour (maida), and excessive carbohydrates."]}),(0,r.jsxs)("div",{className:"mt-6 flex flex-wrap gap-3",children:[(0,r.jsx)(i(),{href:"/products",className:"inline-block bg-emerald-700 text-white px-5 py-3 rounded-lg font-medium hover:bg-emerald-600 transition",children:"Explore Products"}),(0,r.jsx)(i(),{href:"/contact",className:"inline-block border border-emerald-700 text-emerald-700 px-5 py-3 rounded-lg hover:bg-emerald-50 transition",children:"Contact Us"})]})]}),(0,r.jsx)("div",{className:"relative h-64 md:h-80 p-4 flex items-center justify-center",children:(0,r.jsxs)("div",{className:"w-full h-full rounded-xl overflow-hidden relative",children:[(0,r.jsx)("img",{src:"https://9nutz.com/wp-content/uploads/2025/06/Millet_Murukku_19-1000x1000.webp",alt:"About 9Nutz: assorted healthy snacks",className:"w-full h-full object-cover block",style:{display:"block"}}),(0,r.jsx)("div",{className:"absolute bottom-4 left-4 bg-black/40 text-white text-sm px-3 py-1 rounded-md",children:"About 9Nutz"})]})})]})}),(0,r.jsxs)("section",{className:"bg-white rounded-2xl shadow-sm border p-8 mb-8",children:[(0,r.jsx)("h2",{className:"text-2xl font-semibold text-gray-900 mb-4",children:"Our Story & Products"}),(0,r.jsxs)("div",{className:"prose max-w-none text-gray-700",children:[(0,r.jsx)("p",{children:"By sticking to our commitment of providing value-added foods made with millets—free from sugar, refined flour (maida), and high levels of carbohydrates—we offer a wide range of snacks made with 9 types of millets:"}),(0,r.jsxs)("ul",{children:[(0,r.jsx)("li",{children:"Traditionally made sweets"}),(0,r.jsx)("li",{children:"Biscuits & millet cookies"}),(0,r.jsx)("li",{children:"Millet chocolates"}),(0,r.jsx)("li",{children:"Chikkis (jaggery-based sweet cakes)"}),(0,r.jsx)("li",{children:"Nutri bars & energy bites"}),(0,r.jsx)("li",{children:"Namkeens (savory snacks)"}),(0,r.jsx)("li",{children:"Breakfast premixes & healthy chips"})]}),(0,r.jsx)("p",{children:"Our target customers include students (schools & colleges), hospitals, IT companies and any group that wants to make healthier snack choices. We want to contribute to a healthy future for our youth — enabling better food choices and healthier lives."})]})]}),(0,r.jsxs)("section",{className:"grid gap-6 md:grid-cols-2 mb-8",children:[(0,r.jsxs)("div",{className:"bg-white rounded-2xl shadow-sm border p-8",children:[(0,r.jsx)("h3",{className:"text-xl font-semibold text-gray-900 mb-3",children:"What Makes Us Different"}),(0,r.jsxs)("ul",{className:"space-y-4 text-gray-700",children:[(0,r.jsxs)("li",{className:"flex items-start gap-3",children:[(0,r.jsx)("div",{className:"w-9 h-9 rounded-md bg-green-50 text-green-700 flex items-center justify-center font-bold",children:"\uD83C\uDF31"}),(0,r.jsxs)("div",{children:[(0,r.jsx)("strong",{children:"Farm-Fresh Ingredients"}),(0,r.jsx)("div",{className:"text-sm text-gray-600",children:"We source directly from trusted farms to ensure the purest millets, nuts, and natural ingredients."})]})]}),(0,r.jsxs)("li",{className:"flex items-start gap-3",children:[(0,r.jsx)("div",{className:"w-9 h-9 rounded-md bg-green-50 text-green-700 flex items-center justify-center font-bold",children:"\uD83D\uDCAA"}),(0,r.jsxs)("div",{children:[(0,r.jsx)("strong",{children:"Health-First Recipes"}),(0,r.jsx)("div",{className:"text-sm text-gray-600",children:"Products crafted to support healthy lifestyles — high in fiber and nutrients."})]})]}),(0,r.jsxs)("li",{className:"flex items-start gap-3",children:[(0,r.jsx)("div",{className:"w-9 h-9 rounded-md bg-green-50 text-green-700 flex items-center justify-center font-bold",children:"\uD83C\uDF6F"}),(0,r.jsxs)("div",{children:[(0,r.jsx)("strong",{children:"No Compromise on Taste"}),(0,r.jsx)("div",{className:"text-sm text-gray-600",children:"Traditional recipes meet modern nutrition — wholesome AND delicious."})]})]}),(0,r.jsxs)("li",{className:"flex items-start gap-3",children:[(0,r.jsx)("div",{className:"w-9 h-9 rounded-md bg-green-50 text-green-700 flex items-center justify-center font-bold",children:"\uD83C\uDF3E"}),(0,r.jsxs)("div",{children:[(0,r.jsx)("strong",{children:"Empowering Indian Agriculture"}),(0,r.jsx)("div",{className:"text-sm text-gray-600",children:"We support local farmers and promote millets & superfoods for sustainability."})]})]}),(0,r.jsxs)("li",{className:"flex items-start gap-3",children:[(0,r.jsx)("div",{className:"w-9 h-9 rounded-md bg-green-50 text-green-700 flex items-center justify-center font-bold",children:"♻️"}),(0,r.jsxs)("div",{children:[(0,r.jsx)("strong",{children:"Sustainable Practices"}),(0,r.jsx)("div",{className:"text-sm text-gray-600",children:"From eco-friendly packaging to reduced kitchen waste, we work to protect the planet."})]})]})]})]}),(0,r.jsxs)("div",{className:"bg-white rounded-2xl shadow-sm border p-8",children:[(0,r.jsx)("h3",{className:"text-xl font-semibold text-gray-900 mb-3",children:"Our Vision"}),(0,r.jsx)("p",{className:"text-gray-700 mb-4",children:"To be the go-to brand for nutritious, tasty snacks across India — empowering families to choose health without sacrificing flavor."}),(0,r.jsx)("h4",{className:"font-semibold text-gray-900 mb-2",children:"Target customers"}),(0,r.jsx)("p",{className:"text-gray-700 mb-4",children:"Students, schools & colleges, hospitals, corporate offices (IT & others), gifting & events — anyone seeking healthier snacking options."}),(0,r.jsxs)("div",{children:[(0,r.jsx)("h4",{className:"font-semibold text-gray-900 mb-2",children:"How we help"}),(0,r.jsxs)("ul",{className:"list-disc pl-5 text-gray-700",children:[(0,r.jsx)("li",{children:"Nutritious alternatives to common snacks"}),(0,r.jsx)("li",{children:"Bulk & event supply"}),(0,r.jsx)("li",{children:"Gifting-ready packaging and combos"})]})]})]})]}),(0,r.jsxs)("section",{className:"bg-white rounded-2xl shadow-sm border p-8 mb-8 text-center",children:[(0,r.jsx)("h3",{className:"text-2xl font-bold text-gray-900 mb-4",children:"Join us in making snacking healthier"}),(0,r.jsx)("p",{className:"text-gray-700 mb-6",children:"Whether you’re a customer, a retailer, or someone interested in partnering — we’d love to hear from you."}),(0,r.jsxs)("div",{className:"flex flex-col sm:flex-row gap-4 justify-center",children:[(0,r.jsx)(i(),{href:"/products",className:"inline-block bg-emerald-700 text-white px-6 py-3 rounded-lg hover:bg-emerald-600 transition",children:"Shop Now"}),(0,r.jsx)(i(),{href:"/franchise",className:"inline-block border border-emerald-700 text-emerald-700 px-6 py-3 rounded-lg hover:bg-emerald-50 transition",children:"Franchise With Us"}),(0,r.jsx)(i(),{href:"/contact",className:"inline-block bg-white border border-gray-200 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition",children:"Contact Team"})]})]})]})})})}s(8164),s(6658),s(2550)},2550:function(e,t){"use strict";t.Z={src:"/_next/static/media/9nutz_about.78abce65.jpg",height:960,width:1280,blurDataURL:"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAYACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAAAgEBAAAAAAAAAAAAAAAAAAAAAv/aAAwDAQACEAMQAAAAkB//xAAcEAEAAgEFAAAAAAAAAAAAAAADAQIhAAUSIlH/2gAIAQEAAT8ATdmsROhlbPWZpXlmfdf/xAAVEQEBAAAAAAAAAAAAAAAAAAAAAf/aAAgBAgEBPwCv/8QAFhEAAwAAAAAAAAAAAAAAAAAAAAEx/9oACAEDAQE/AFD/2Q==",blurWidth:8,blurHeight:6}},4033:function(e,t,s){e.exports=s(290)},5925:function(e,t,s){"use strict";let r,a;s.r(t),s.d(t,{CheckmarkIcon:function(){return W},ErrorIcon:function(){return _},LoaderIcon:function(){return H},ToastBar:function(){return et},ToastIcon:function(){return Y},Toaster:function(){return ei},default:function(){return en},resolveValue:function(){return k},toast:function(){return Q},useToaster:function(){return U},useToasterStore:function(){return L}});var i,n=s(2265);let o={data:""},l=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||o},c=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,d=/\/\*[^]*?\*\/|  +/g,u=/\n+/g,m=(e,t)=>{let s="",r="",a="";for(let i in e){let n=e[i];"@"==i[0]?"i"==i[1]?s=i+" "+n+";":r+="f"==i[1]?m(n,i):i+"{"+m(n,"k"==i[1]?"":t)+"}":"object"==typeof n?r+=m(n,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=n&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),a+=m.p?m.p(i,n):i+":"+n+";")}return s+(t&&a?t+"{"+a+"}":a)+r},h={},p=e=>{if("object"==typeof e){let t="";for(let s in e)t+=s+p(e[s]);return t}return e},f=(e,t,s,r,a)=>{var i;let n=p(e),o=h[n]||(h[n]=(e=>{let t=0,s=11;for(;t<e.length;)s=101*s+e.charCodeAt(t++)>>>0;return"go"+s})(n));if(!h[o]){let t=n!==e?e:(e=>{let t,s,r=[{}];for(;t=c.exec(e.replace(d,""));)t[4]?r.shift():t[3]?(s=t[3].replace(u," ").trim(),r.unshift(r[0][s]=r[0][s]||{})):r[0][t[1]]=t[2].replace(u," ").trim();return r[0]})(e);h[o]=m(a?{["@keyframes "+o]:t}:t,s?"":"."+o)}let l=s&&h.g?h.g:null;return s&&(h.g=h[o]),i=h[o],l?t.data=t.data.replace(l,i):-1===t.data.indexOf(i)&&(t.data=r?i+t.data:t.data+i),o},g=(e,t,s)=>e.reduce((e,r,a)=>{let i=t[a];if(i&&i.call){let e=i(s),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":m(e,""):!1===e?"":e}return e+r+(null==i?"":i)},"");function x(e){let t=this||{},s=e.call?e(t.p):e;return f(s.unshift?s.raw?g(s,[].slice.call(arguments,1),t.p):s.reduce((e,s)=>Object.assign(e,s&&s.call?s(t.p):s),{}):s,l(t.target),t.g,t.o,t.k)}x.bind({g:1});let y,b,A,v=x.bind({k:1});function j(e,t){let s=this||{};return function(){let r=arguments;function a(i,n){let o=Object.assign({},i),l=o.className||a.className;s.p=Object.assign({theme:b&&b()},o),s.o=/ *go\d+/.test(l),o.className=x.apply(s,r)+(l?" "+l:""),t&&(o.ref=n);let c=e;return e[0]&&(c=o.as||e,delete o.as),A&&c[0]&&A(o),y(c,o)}return t?t(a):a}}var w=e=>"function"==typeof e,k=(e,t)=>w(e)?e(t):e,N=(r=0,()=>(++r).toString()),E=()=>{if(void 0===a&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");a=!e||e.matches}return a},C="default",I=(e,t)=>{let{toastLimit:s}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,s)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:r}=t;return I(e,{type:e.toasts.find(e=>e.id===r.id)?1:0,toast:r});case 3:let{toastId:a}=t;return{...e,toasts:e.toasts.map(e=>e.id===a||void 0===a?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},D=[],M={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},T={},Z=(e,t=C)=>{T[t]=I(T[t]||M,e),D.forEach(([e,s])=>{e===t&&s(T[t])})},z=e=>Object.keys(T).forEach(t=>Z(e,t)),F=e=>Object.keys(T).find(t=>T[t].toasts.some(t=>t.id===e)),O=(e=C)=>t=>{Z(t,e)},P={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},L=(e={},t=C)=>{let[s,r]=(0,n.useState)(T[t]||M),a=(0,n.useRef)(T[t]);(0,n.useEffect)(()=>(a.current!==T[t]&&r(T[t]),D.push([t,r]),()=>{let e=D.findIndex(([e])=>e===t);e>-1&&D.splice(e,1)}),[t]);let i=s.toasts.map(t=>{var s,r,a;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(s=e[t.type])?void 0:s.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(r=e[t.type])?void 0:r.duration)||(null==e?void 0:e.duration)||P[t.type],style:{...e.style,...null==(a=e[t.type])?void 0:a.style,...t.style}}});return{...s,toasts:i}},S=(e,t="blank",s)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...s,id:(null==s?void 0:s.id)||N()}),B=e=>(t,s)=>{let r=S(t,e,s);return O(r.toasterId||F(r.id))({type:2,toast:r}),r.id},Q=(e,t)=>B("blank")(e,t);Q.error=B("error"),Q.success=B("success"),Q.loading=B("loading"),Q.custom=B("custom"),Q.dismiss=(e,t)=>{let s={type:3,toastId:e};t?O(t)(s):z(s)},Q.dismissAll=e=>Q.dismiss(void 0,e),Q.remove=(e,t)=>{let s={type:4,toastId:e};t?O(t)(s):z(s)},Q.removeAll=e=>Q.remove(void 0,e),Q.promise=(e,t,s)=>{let r=Q.loading(t.loading,{...s,...null==s?void 0:s.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let a=t.success?k(t.success,e):void 0;return a?Q.success(a,{id:r,...s,...null==s?void 0:s.success}):Q.dismiss(r),e}).catch(e=>{let a=t.error?k(t.error,e):void 0;a?Q.error(a,{id:r,...s,...null==s?void 0:s.error}):Q.dismiss(r)}),e};var $=1e3,U=(e,t="default")=>{let{toasts:s,pausedAt:r}=L(e,t),a=(0,n.useRef)(new Map).current,i=(0,n.useCallback)((e,t=$)=>{if(a.has(e))return;let s=setTimeout(()=>{a.delete(e),o({type:4,toastId:e})},t);a.set(e,s)},[]);(0,n.useEffect)(()=>{if(r)return;let e=Date.now(),a=s.map(s=>{if(s.duration===1/0)return;let r=(s.duration||0)+s.pauseDuration-(e-s.createdAt);if(r<0){s.visible&&Q.dismiss(s.id);return}return setTimeout(()=>Q.dismiss(s.id,t),r)});return()=>{a.forEach(e=>e&&clearTimeout(e))}},[s,r,t]);let o=(0,n.useCallback)(O(t),[t]),l=(0,n.useCallback)(()=>{o({type:5,time:Date.now()})},[o]),c=(0,n.useCallback)((e,t)=>{o({type:1,toast:{id:e,height:t}})},[o]),d=(0,n.useCallback)(()=>{r&&o({type:6,time:Date.now()})},[r,o]),u=(0,n.useCallback)((e,t)=>{let{reverseOrder:r=!1,gutter:a=8,defaultPosition:i}=t||{},n=s.filter(t=>(t.position||i)===(e.position||i)&&t.height),o=n.findIndex(t=>t.id===e.id),l=n.filter((e,t)=>t<o&&e.visible).length;return n.filter(e=>e.visible).slice(...r?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+a,0)},[s]);return(0,n.useEffect)(()=>{s.forEach(e=>{if(e.dismissed)i(e.id,e.removeDelay);else{let t=a.get(e.id);t&&(clearTimeout(t),a.delete(e.id))}})},[s,i]),{toasts:s,handlers:{updateHeight:c,startPause:l,endPause:d,calculateOffset:u}}},_=j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${v`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${v`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${v`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,H=j("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${v`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`} 1s linear infinite;
`,W=j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${v`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${v`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,q=j("div")`
  position: absolute;
`,R=j("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,V=j("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${v`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,Y=({toast:e})=>{let{icon:t,type:s,iconTheme:r}=e;return void 0!==t?"string"==typeof t?n.createElement(V,null,t):t:"blank"===s?null:n.createElement(R,null,n.createElement(H,{...r}),"loading"!==s&&n.createElement(q,null,"error"===s?n.createElement(_,{...r}):n.createElement(W,{...r})))},G=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,K=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,J=j("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,X=j("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,ee=(e,t)=>{let s=e.includes("top")?1:-1,[r,a]=E()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[G(s),K(s)];return{animation:t?`${v(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${v(a)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},et=n.memo(({toast:e,position:t,style:s,children:r})=>{let a=e.height?ee(e.position||t||"top-center",e.visible):{opacity:0},i=n.createElement(Y,{toast:e}),o=n.createElement(X,{...e.ariaProps},k(e.message,e));return n.createElement(J,{className:e.className,style:{...a,...s,...e.style}},"function"==typeof r?r({icon:i,message:o}):n.createElement(n.Fragment,null,i,o))});i=n.createElement,m.p=void 0,y=i,b=void 0,A=void 0;var es=({id:e,className:t,style:s,onHeightUpdate:r,children:a})=>{let i=n.useCallback(t=>{if(t){let s=()=>{r(e,t.getBoundingClientRect().height)};s(),new MutationObserver(s).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return n.createElement("div",{ref:i,className:t,style:s},a)},er=(e,t)=>{let s=e.includes("top"),r=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:E()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(s?1:-1)}px)`,...s?{top:0}:{bottom:0},...r}},ea=x`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ei=({reverseOrder:e,position:t="top-center",toastOptions:s,gutter:r,children:a,toasterId:i,containerStyle:o,containerClassName:l})=>{let{toasts:c,handlers:d}=U(s,i);return n.createElement("div",{"data-rht-toaster":i||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...o},className:l,onMouseEnter:d.startPause,onMouseLeave:d.endPause},c.map(s=>{let i=s.position||t,o=er(i,d.calculateOffset(s,{reverseOrder:e,gutter:r,defaultPosition:t}));return n.createElement(es,{id:s.id,key:s.id,onHeightUpdate:d.updateHeight,className:s.visible?ea:"",style:o},"custom"===s.type?k(s.message,s):a?a(s):n.createElement(et,{toast:s,position:i}))}))},en=Q}},function(e){e.O(0,[4737,1396,7037,5884,6658,8164,2971,7864,1744],function(){return e(e.s=8645)}),_N_E=e.O()}]);